import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import yfinance as yf
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller
from prophet import Prophet
import warnings

# --- CONFIGURATION ---
warnings.filterwarnings('ignore')
sns.set_style("darkgrid")
plt.rcParams['figure.figsize'] = (14, 7)

class SilverAnalyst:
    def __init__(self, ticker='SI=F', start='2016-01-01', end='2026-01-19'):
        self.ticker = ticker
        self.start = start
        self.end = end
        self.df = None
        self.model = None
        self.forecast = None

    def fetch_data(self):
        """Fetches historical data from Yahoo Finance"""
        print(f"⬇️ Fetching data for {self.ticker} ({self.start} to {self.end})...")
        self.df = yf.download(self.ticker, start=self.start, end=self.end)
        
        # Flatten MultiIndex if present
        if isinstance(self.df.columns, pd.MultiIndex):
            self.df.columns = self.df.columns.get_level_values(0)
            
        self.df.reset_index(inplace=True)
        self.df['Date'] = pd.to_datetime(self.df['Date'])
        
        # Handle missing data
        initial_rows = len(self.df)
        self.df.ffill(inplace=True)
        print(f"✅ Data loaded. Rows: {len(self.df)} (filled {len(self.df) - initial_rows} gaps).")
        
        # Save raw data
        self.df.to_csv('silver_prices_data.csv', index=False)
        print("💾 Raw data saved to 'silver_prices_data.csv'")

    def perform_eda(self):
        """Performs Exploratory Data Analysis and generates plots"""
        if self.df is None:
            raise ValueError("Data not loaded.")
        
        print("\n--- 📊 EDA Summary ---")
        print(self.df.describe())
        
        # 1. Price History Plot
        plt.figure(figsize=(15, 7))
        plt.plot(self.df['Date'], self.df['Close'], label='Close Price', color='#2c3e50')
        plt.plot(self.df['Date'], self.df['Close'].rolling(window=50).mean(), label='50-Day SMA', color='#f1c40f', linestyle='--')
        plt.title(f'{self.ticker} Price History (2016-2026)')
        plt.legend()
        plt.savefig('silver_price_history.png')
        print("🖼️ 'silver_price_history.png' saved.")
        plt.close()

        # 2. Daily Returns
        self.df['Daily_Return'] = self.df['Close'].pct_change()
        plt.figure(figsize=(10, 6))
        sns.histplot(self.df['Daily_Return'].dropna(), bins=100, kde=True, color='teal')
        plt.title('Distribution of Daily Returns')
        plt.savefig('silver_returns_dist.png')
        print("🖼️ 'silver_returns_dist.png' saved.")
        plt.close()

    def run_statistical_tests(self):
        """Runs ADF and Decomposition"""
        print("\n--- 🧮 Statistical Analysis ---")
        
        # ADF Test
        result = adfuller(self.df['Close'].dropna())
        print(f"ADF Statistic: {result[0]:.4f}")
        print(f"p-value: {result[1]:.4f}")
        if result[1] > 0.05:
            print("👉 Observation: Series is NON-STATIONARY (p > 0.05)")
        else:
            print("👉 Observation: Series is STATIONARY (p < 0.05)")

    def train_forecast_model(self):
        """Trains Prophet model and forecasts Q1 2026"""
        print("\n--- 🤖 Training Prophet Model ---")
        
        # Prepare data for Prophet
        prophet_df = self.df[['Date', 'Close']].rename(columns={'Date': 'ds', 'Close': 'y'})
        
        # Configure model
        self.model = Prophet(
            daily_seasonality=False,
            yearly_seasonality=True,
            weekly_seasonality=True,
            changepoint_prior_scale=0.05
        )
        self.model.add_country_holidays(country_name='US')
        
        self.model.fit(prophet_df)
        
        # Create future dataframe (90 days into future)
        future = self.model.make_future_dataframe(periods=90)
        self.forecast = self.model.predict(future)
        
        # Plotting Forecast
        fig1 = self.model.plot(self.forecast)
        plt.title('Silver Price Forecast Q1 2026')
        plt.savefig('silver_forecast_plot.png')
        plt.close()
        
        fig2 = self.model.plot_components(self.forecast)
        plt.savefig('silver_forecast_components.png')
        plt.close()
        print("🖼️ Forecast plots saved.")

    def export_predictions(self):
        """Exports the forecast for 2026"""
        if self.forecast is None:
            return
            
        # Filter for dates after the dataset end (Prediction phase)
        last_real_date = self.df['Date'].max()
        future_mask = self.forecast['ds'] > last_real_date
        
        predictions = self.forecast.loc[future_mask, ['ds', 'yhat', 'yhat_lower', 'yhat_upper']]
        predictions.rename(columns={
            'ds': 'Date', 
            'yhat': 'Predicted_Price',
            'yhat_lower': 'Lower_Confidence_Bound',
            'yhat_upper': 'Upper_Confidence_Bound'
        }, inplace=True)
        
        filename = 'silver_price_forecast_2026.csv'
        predictions.to_csv(filename, index=False)
        print(f"✅ Future predictions saved to '{filename}'")

if __name__ == "__main__":
    print("🚀 Starting Silver Price Analysis Engine...")
    analyst = SilverAnalyst()
    analyst.fetch_data()
    analyst.perform_eda()
    analyst.run_statistical_tests()
    analyst.train_forecast_model()
    analyst.export_predictions()
    print("🎉 Analysis Complete.")